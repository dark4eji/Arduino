# LiquidCrystal_I2C

Russian text for I2C LCD displays with/without internal russian fonts.

For Arduino/Esp8266/Esp32
